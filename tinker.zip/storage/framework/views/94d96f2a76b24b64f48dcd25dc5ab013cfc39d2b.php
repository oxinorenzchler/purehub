<div class="panel-body">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <ul class="list-inline">
            <li>
                <?php if($user->profile() == null): ?>
                <a href="" class="elegant bold orange-hover"><img src="<?php echo e($user->defaultProfile()); ?>" class="img-circle" height="50" width="50"> <?php echo e($user->name); ?></a>
                <?php else: ?>
                    <a href="" class="elegant bold orange-hover"><img src="<?php echo e($user->profilePath().$user->profile()); ?>" class="img-circle" height="50" width="50"> <?php echo e($user->name); ?></a>
                <?php endif; ?>
            </li>
            <li class="pull-right">
                <a href="" class="btn btn-sm btn-primary">
                    Follow <i class="fas fa-user-plus"></i>
                </a>
            </li>
        </ul>
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>