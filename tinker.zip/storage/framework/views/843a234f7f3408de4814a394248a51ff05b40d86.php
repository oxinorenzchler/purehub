<?php $__env->startSection('title',$profile->name.' | Home'); ?>

<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<?php echo $__env->make('includes.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid mt-70">
    <div class="row" id="content">
        
        <div class="col-md-3 hide-mobile sticky">
            <div class="panel">
                <div class="panel-heading text-center">
                        <a href="">
                        <img src="<?php echo e($profile->profile()); ?>" class="img-circle" alt="<?php echo e($profile->name); ?>" height="250">
                        </a>
                        <a href="" class="elegant bold size-1"><?php echo e($profile->name); ?></a>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4 col-sm-4">
                            <a href="" class="elegant bold orange-hover">Chinismis</a>
                        <p class="cool-orange bold"><?php echo e(count($postDetails)); ?></p>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="" class="elegant bold orange-hover">Following</a>
                            <p class="cool-orange bold">5</p>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="" class="elegant bold orange-hover">Followers</a>
                            <p class="cool-orange bold">3.4mil</p>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <ul class="list-unstyled ml-3">
                            <li class="mb-3">
                                <i class="far fa-newspaper newspaper"></i><a href="" class="elegant bold side-nav ml-5">My Newsfeeds</a>
                            </li>
                            <li class="mb-3">
                                <i class="fas fa-users people"></i><a href="" class="elegant bold side-nav ml-5">People nearby</a>
                            </li>
                            <li class="mb-3">
                                <i class="fas fa-camera-retro photo"></i><a href="" class="elegant bold side-nav ml-5"> Photos</a>
                            </li>
                            <li>
                                <i class="far fa-eye-slash privacy"></i><a href="" class="elegant bold side-nav ml-5"> Privacy, Terms &amp; Agreement</a>
                            </li>
                        </ul>
                    </div>
                    <span id="google_translate_element" class="text-center"></span>
                </div>
                
            </div>
            
        </div>

        
        <div class="col-md-6">
            <h1 class="text-center">People nearby</h1>
                <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="media">
                        <a href="<?php echo e(url('/getSearch/'.$user->id)); ?>" class="pull-left">
                        <img class="media-object img-circle" src="<?php echo e($user->profile()); ?>" alt="<?php echo e($user->name); ?>" height="100">
                        </a>
                        <div class="media-body">
                        <h4 class="heading"><a href="<?php echo e(url('/getSearch/'.$user->id)); ?>"><?php echo e($user->name); ?></a></h4>
                        <p><?php echo e($user->email); ?></p>
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="col-md-3 hide-mobile sticky">
                <div class="panel panel-default">
                    <div class="panel-heading elegant bold">Getting bored? Checkout this awesome games!</div>
                        <div class="panel-body">
                            <p class="cool-orange bold"><i class="fas fa-gamepad"></i> Featured Games</p>
                            <a href="" class="w-100" title="The Sweet Escape Mystery Game">
                                <img src="<?php echo e(asset('img/sweetescape.svg')); ?>" alt="The Sweet Escape" class="img-rounded w-100 shadow-hover">
                            </a>
                        </div>
                </div>

        </div>
    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>