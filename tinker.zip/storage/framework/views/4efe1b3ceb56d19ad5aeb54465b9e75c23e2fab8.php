<?php $__env->startSection('title',$profile->name.' | Home'); ?>

<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="container mt-70">
    <div class="row">
        
        <div class="col-md-3">
                <div class="panel sticky">
                    <div class="panel-heading text-center bg-cool-orange">
                            <a href="">
                                <img src="<?php echo e($profile->profile().'&size=200'); ?>" class="img-circle mb-2" alt="">
                            </a>
                            <form action="" id="profile-pic-form">
                                <input type="file" id="profpic" name="profpic">
                                <div class="form-group">
                                        <label for="attachment">
                                                <p id="path-preview"></p>
                                        </label>
                                </div>
                                <div class="form-group">
                                        <button type="submit" class="btn btn-sm btn-primary">Change</button>
                                </div>
                            </form>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="" class="elegant bold orange-hover">Chinismis</a>
                                <p class="cool-orange bold">50</p>
                            </div>
                            <div class="col-md-4">
                                <a href="" class="elegant bold orange-hover">Following</a>
                                <p class="cool-orange bold">5</p>
                            </div>
                            <div class="col-md-4">
                                <a href="" class="elegant bold orange-hover">Followers</a>
                                <p class="cool-orange bold">1.4mil</p>
                            </div>
                        </div>
                        <h3 class="elegant bold"><?php echo e($profile->name); ?></h3>
                        <p>
                            <i class="fas fa-briefcase"></i>
                            <?php if($profile->work != null): ?>
                                <span class="work"><?php echo e($profile->work); ?></span>
                            <?php else: ?>
                                <span class="work">Do you have a life?</span>
                            <?php endif; ?>
                        </p>
                        <p>
                            <i class="fas fa-location-arrow"></i>
                            <?php if($profile->address != null): ?>
                                <span class="address"><?php echo e($profile->address); ?></span>
                            <?php else: ?>
                                <span class="address">Where are you from?</span>
                            <?php endif; ?>
                        </p>
                        <p>
                            <i class="fas fa-pencil-alt"></i>
                            <?php if($profile->bio != null): ?>
                                <span class="bio"><?php echo e($profile->bio); ?></span>
                            <?php else: ?>
                                <span class="bio">Tell us about yourself?</span>
                            <?php endif; ?>
                        </p>
                        <p>
                            <i class="far fa-calendar-alt"></i>                         
                            Joined  <?php echo e(date("M d Y", strtotime($profile->created_at))); ?>

                        </p>
                    </div>
                </div>
                
                <div class="panel panel-default">
                    <div class="panel-heading elegant bold  bg-cool-orange">Visit our partners! Connecting dots</div>
                        <div class="panel-body text-center">
                            <div class="form-group">
                                    <a href="">
                                        <img src="<?php echo e($profile->profile().'&size=60'); ?>" alt="" class="img-circle"> 
                                    </a>  
                                    <a href="" class="cool-orange bold elegant-hover size-1">Pure Room</a>
                            </div>
                            <div class="form-group">
                                    <a href="">
                                        <img src="<?php echo e($profile->profile().'&size=60'); ?>" alt="" class="img-circle"> 
                                    </a>  
                                    <a href="" class="cool-orange bold elegant-hover size-1">Pure Ian</a>
                            </div>
                            <div class="form-group">
                                    <a href="">
                                        <img src="<?php echo e($profile->profile().'&size=60'); ?>" alt="" class="img-circle"> 
                                    </a>  
                                    <a href="" class="cool-orange bold elegant-hover size-1">Pure Taxi</a>
                            </div>      
                        </div>
                </div>
            </div>

        
        <div class="col-md-6">
                <div class="panel panel-success">
                        <div class="panel-body" id="panel-body">
                        <form action="/publish" method="POST" id="post-form" enctype="multipart/form-data">
                                <?php echo e(@csrf_field()); ?>

                                <div class="row">
                                        <input type="file" id="attachment" name="attachment">
                                    <div class="col-sm-1 text-center" id="user-mini-profile">
                                    <img src="<?php echo e($profile->profile().'&size=40'); ?>" class="img-circle" alt="">
                                    </div>
                                    <div class="col-sm-11">
                                        <textarea name="post" id="post" cols="1" rows="1" class="form-control" placeholder="What's on your brain?">
                                            
                                        </textarea>
                                    </div>
                                </div> 
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-11">
                                        <label for="attachment">
                                            <span class="far fa-image post-media-icon"></span>
                                             
                                            <span id="path-preview"></span>
                                        </label>
                                        <div class="pull-right">
                                            <button type="submit" class="btn btn-success" id="publish-btn">Publish</button>
                                        </div>
                                    </div>
                                </div>   
                            </form>      
                        </div>
                    </div>
                <?php if(count($posts)<1): ?>
            <h1 class="text-center">Ang lungkot ng buhay mo te!</h1>
            <?php else: ?>
            <div class="postDiv">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-success">
                <div class="panel-heading"><a href=""><img src="https://www.gravatar.com/avatar/<?php echo e(md5($post->user->name)); ?>?d=monsterid&s=50" class="img-circle" alt=""> <?php echo e($post->user->name); ?></a> <span><?php echo e($post->created_at->diffForHumans()); ?></span></div>
                    <div class="panel-body">

                            <?php if($post->post_body != null): ?>
                                <div class="text-body">
                                        <?php echo e($post->post_body); ?>   
                                </div>
                            <?php endif; ?>
                            
                    <?php if($post->media != null): ?>
                        <div class="img-post-container">
                            <img src="<?php echo e($post->media); ?>" alt="" class="img-responsive post-img img-rounded">
                        </div>
                    <?php endif; ?>
                    </div>
                <div class="panel-footer">

                    
                    
                    <?php if(Auth::user()->likes->contains($post->id)): ?>
                        

                        <a class="postClass<?php echo e($post->id); ?>" onclick="unlike(<?php echo e(Auth::id()); ?>,<?php echo e($post->id); ?>)">Unlike <i class="fas fa-heart"></i></a>
                    <?php else: ?>
                        
                        <a class="postClass<?php echo e($post->id); ?>" onclick="like(<?php echo e(Auth::id()); ?>,<?php echo e($post->id); ?>)">Like <i class="far fa-heart"></i></a>
                    <?php endif; ?>


                    <a href="" class="comment-link">Comment</a>


                     
                     <div class="commentDiv">
                            <div class="row mt-2">
                                    <div class="col-sm-12">
                                        <div class="media">
                                            <div class="media-left">
                                            <a href="#">
                                                <img class="media-object img-circle" src="<?php echo e($profile->profile().'&size=30'); ?>" alt="...">
                                            </a>
                                            </div>
                                            <div class="media-body">
                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque, sit ex saepe odit facilis doloribus quibusdam laborum commodi at, aperiam ipsum eos nemo reiciendis, dolorem quas tempora. At, quam labore.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        
                    </div>
                        <div class="row">
                            <div class="col-sm-1"></div>
                            <div class="col-sm-11">
                                <div class="media">
                                        <div class="media-left">
                                            <a href="#">
                                                <img class="media-object img-circle" src="<?php echo e($profile->profile().'&size=30'); ?>" alt="...">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <form action="" class="comment-form">
                                                <div class="form-group">
                                                        <textarea name="comment-body" class="comment-body<?php echo e($post->id); ?> form-control" cols="65" rows="3" placeholder="Anong say mo?"></textarea>
                                                </div>
                                            <div class="form-group">
                                                    <button type="submit" id="btn-comment" class="btn btn-primary btn-sm" onclick="comment(<?php echo e($post->id); ?>)">Comment</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-3 hide-mobile">
                <div class="panel panel-default">
                    <div class="panel-heading bg-cool-orange elegant bold">Mga Chismosa <a href="">Refresh</a></div>
                        <div class="panel-body">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <div>
                                       <a href=""><img src="https://www.gravatar.com/avatar/<?php echo e(md5($user->id)); ?>?d=monsterid&s=50" alt="" class="img-circle"></a><span class="margin-1"><button class="btn rounded-outline-btn">Follow</button></span>
                                        <p><?php echo e($user->name); ?></p>
                                   </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading bg-cool-orange elegant bold">Getting bored? Checkout this awesome games!</div>
                        <div class="panel-body">
                            <p class="cool-orange bold"><i class="fas fa-gamepad"></i> Featured Games</p>
                            <a href="" class="w-100" title="The Sweet Escape Mystery Game">
                                <img src="<?php echo e(asset('img/sweetescape.svg')); ?>" alt="The Sweet Escape" class="img-rounded w-100 shadow-hover">
                            </a>
                        </div>
                </div>

        </div>
    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>