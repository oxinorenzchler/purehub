<?php $__env->startSection('title',$profile->name.' | Home'); ?>

<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<?php echo $__env->make('includes.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid mt-70">
    <div class="row">
        
        <div class="col-md-3 sticky">
                <div class="panel ">
                    <div class="panel-heading text-center">
                            <a href="">
                                <?php if($profile->profile() == null): ?>
                                    <img src="<?php echo e(url($profile->defaultProfile())); ?>" class="img-circle" alt="<?php echo e($profile->name); ?>" width="200" height="200">
                                <?php else: ?>
                                    <img src="<?php echo e(url($profile->profilePath().$profile->profile())); ?>" class="img-circle" alt="<?php echo e($profile->name); ?>" height="200" width="200">
                                <?php endif; ?>
                            </a>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="" class="elegant bold orange-hover">Posts</a>
                            <p class="cool-orange bold"><?php echo e(count($posts)); ?></p>
                            </div>
                            <div class="col-md-4">
                                <a href="" class="elegant bold orange-hover">Following</a>
                                <p class="cool-orange bold">5</p>
                            </div>
                            <div class="col-md-4">
                                <a href="" class="elegant bold orange-hover">Followers</a>
                                <p class="cool-orange bold">1.4mil</p>
                            </div>
                        </div>
                        <h3 class="elegant bold"><?php echo e($profile->name); ?></h3>
                        <p>
                            <i class="fas fa-briefcase"></i>
                            <?php if($profile->work != null): ?>
                                <span class="work"><?php echo e($profile->work); ?></span>
                            <?php else: ?>
                                <span class="work">Do you have a life?</span>
                            <?php endif; ?>
                        </p>
                        <p>
                            <i class="fas fa-location-arrow"></i>
                            <?php if($profile->address != null): ?>
                                <span class="address"><?php echo e($profile->address); ?></span>
                            <?php else: ?>
                                <span class="address">Where are you from?</span>
                            <?php endif; ?>
                        </p>
                        <p>
                            <i class="fas fa-pencil-alt"></i>
                            <?php if($profile->bio != null): ?>
                                <span class="bio"><?php echo e($profile->bio); ?></span>
                            <?php else: ?>
                                <span class="bio">Tell us about yourself?</span>
                            <?php endif; ?>
                        </p>
                        <p>
                            <i class="far fa-calendar-alt"></i>                         
                            Joined  <?php echo e(date("M d Y", strtotime($profile->created_at))); ?>

                        </p>
                        <span id="google_translate_element" class="text-center"></span>
                    </div>
                </div>
            </div>

        
        <div class="col-md-6">
            <div class="panel panel-success">
                <div class="panel-body" id="panel-body">
                <form action="/publish" method="POST" id="post-form" enctype="multipart/form-data">
                        <?php echo e(@csrf_field()); ?>

                        <div class="row">
                                <input type="file" id="attachment" class="attachment" name="attachment">
                            <div class="col-sm-1 text-center" id="user-mini-profile">
                            <div id="profile-post">
                                <?php if($profile->profile() == null): ?>
                                    <img src="<?php echo e(url($profile->defaultProfile())); ?>" alt="<?php echo e($profile->name); ?>" class="img-circle w-100" height="40">
                                <?php else: ?>
                                    <img src="<?php echo e(url($profile->profilePath().$profile->profile())); ?>" class="img-circle w-100" height="40" alt="<?php echo e($profile->name); ?>">
                                <?php endif; ?>
                                
                            </div>
                            </div>
                            <div class="col-sm-11">
                                <textarea name="post" id="post" cols="1" rows="1" class="form-control" placeholder="What's on your brain?" id="text-area-post">
                                    
                                </textarea>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-11">
                                <label for="attachment">
                                    <span class="far fa-image post-media-icon"></span>
                                     
                                    <span id="path-preview"></span>
                                </label>
                                <div class="pull-right">
                                    <button type="submit" class="btn btn-success" id="publish-btn">Publish</button>
                                </div>
                            </div>
                        </div>   
                    </form>      
                </div>
            </div>
           
            <?php if(count($posts)<1): ?>
            <h1 class="text-center">Ang lungkot ng buhay mo te!</h1>
            <div class="postDiv">

            </div>
            <?php else: ?>
            
            <div class="alert alert-success bold alertpublish text-center" role="alert">Post published!</div>
            <div class="alert alert-success bold alertdelete text-center" role="alert">Post Deleted!</div>
            <div class="alert alert-success bold alertedit text-center" role="alert">Post Updated!</div>
            <div class="postDiv">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <div class="panel panel-success post<?php echo e($post->id); ?>">
                
                <div class="panel-heading"> 
                        <a href="">
                            <?php if($post->user->profile() == null): ?>
                                <img src="<?php echo e($post->user->defaultProfile()); ?>" class="img-circle" alt="<?php echo e($post->user->name); ?>" width="40" height="40">
                            <?php else: ?>
                                <img src="<?php echo e(url($post->user->profilePath().$post->user->profile())); ?>" class="img-circle" width="40" height="40" alt="<?php echo e($post->user->name); ?>"><span class="ml-1"><?php echo e($post->user->name); ?></span>
                            <?php endif; ?>
                        </a> 
                        <span class="postTime<?php echo e($post->id); ?>'">
                            <?php echo e($post->updated_at->diffForHumans()); ?>

                        </span>
                        <span class="dropdown text-right">
                            <?php if(Auth::id() == $post->user_id): ?>
                            <button class="btn btn-default btn-sm dropdown-toggle pull-right" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                <span class="fas fa-cogs"></span>
                            </button> 
    
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                <li><a  onclick="showEdit(<?php echo e($post->id); ?>)"><i class="fas fa-edit"></i> Edit</a></li> 
                                <li><a onclick="deletePost(<?php echo e($post->id); ?>)"><i class="fas fa-trash"></i> Delete</a></li> 
                            </ul>

                            <?php endif; ?>
                        </span> 
                    </div>
                    <div class="panel-body">
                        
                            <div class="text-body post-text<?php echo e($post->id); ?>">
                                    <?php echo e($post->post_body); ?>   
                            </div>
                            <textarea name="editposttext<?php echo e($post->id); ?>" id="editposttext" cols="1" rows="3" class="form-control editposttext<?php echo e($post->id); ?>"><?php echo e($post->post_body); ?></textarea>
                            <button onclick="editPost(<?php echo e($post->id); ?>)" class="btn btn-sm btn-primary editpostbtn<?php echo e($post->id); ?>" id="editpostbtn">Save <i class="fas fa-save"></i></button>
                            <button onclick="cancelEditPost(<?php echo e($post->id); ?>)" id="cancelpostbtn" class="btn btn-sm btn-secondary cancelpostbtn<?php echo e($post->id); ?>">Cancel <i class="fas fa-ban"></i></button>
                        
                    <?php if($post->media != null): ?>
                        <div class="img-post-container">
                            <img src="<?php echo e(url($post->user->profilePath().$post->media)); ?>" alt="" class="img-responsive post-img img-rounded">
                        </div>
                    <?php endif; ?>
                    </div>
                <div class="panel-footer">

                    
                    <?php if(Auth::user()->likes->contains($post->id)): ?>
                        
                        <a class="postClass<?php echo e($post->id); ?>" onclick="unlike(<?php echo e(Auth::id()); ?>,<?php echo e($post->id); ?>)">Unlike <i class="fas fa-heart"></i></a>
                    <?php else: ?>
                        
                        <a class="postClass<?php echo e($post->id); ?>" onclick="like(<?php echo e(Auth::id()); ?>,<?php echo e($post->id); ?>)">Like <i class="far fa-heart"></i></a>
                    <?php endif; ?>


                     
                <div class="commentDiv<?php echo e($post->id); ?>">

                           <?php $__currentLoopData = $comments->where('post_id',$post->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mt-2 mb-3">
                                <div class="col-sm-12">
                                <div class="media comment<?php echo e($comment->id); ?>">
                                    <div class="media-left"><a href="#">
                                        <a>
                                        <?php if($comment->user->profile() == null): ?>
                                            <img class="media-object img-circle" src="<?php echo e(url($comment->user->defaultProfile())); ?>" alt="<?php echo e($comment->user->name); ?>" height="30" width="30">
                                        <?php else: ?>
                                            <img class="media-object img-circle" src="<?php echo e($comment->user->profilePath().$comment->user->profile()); ?>" alt="<?php echo e($comment->user->name); ?>" height="30" width="30">
                                        <?php endif; ?>
                                         </a>
                                    </div>
                                    <div class="media-body">
                                        <a href="" class="bold elegant"><?php echo e($comment->user->name); ?></a>
                                    <div class="text-body commenttext<?php echo e($comment->id); ?>">
                                            <p><?php echo e($comment->comment); ?></p>
                                        </div>
                                            <textarea name="editcommenttext<?php echo e($comment->id); ?>" id="editcommenttext" cols="1" rows="3" class="form-control editcommenttext<?php echo e($comment->id); ?>"><?php echo e($comment->comment); ?></textarea>
                                            <button onclick="editComment(<?php echo e($comment->id); ?>)" class="btn btn-sm btn-primary editcommentbtn<?php echo e($comment->id); ?>" id="editcommentbtn">Save <i class="fas fa-save"></i></button>
                                            <button onclick="cancelEditComment(<?php echo e($comment->id); ?>)" id="cancelcommentbtn" class="btn btn-sm btn-secondary cancelcommentbtn<?php echo e($comment->id); ?>">Cancel <i class="fas fa-ban"></i></button>
                                        <div class="pull-right">
                                            
                                            <?php if(Auth::id() == $comment->user_id): ?>
                                                <a onclick="showComment(<?php echo e($comment->id); ?>)" class="mr-1"><i class="fas fa-edit"></i></a>
                                                <a onclick="deleteComment(<?php echo e($comment->id); ?>)"><i class="fas fa-trash"></i></a>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>

                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                        <div class="row">
                            <div class="col-sm-1"></div>
                            <div class="col-sm-11">
                                <div class="media">
                                        <div class="media-left">
                                            <a href="#">
                                                <?php if($profile->profile() == null): ?>
                                                    <img class="media-object img-circle" src="<?php echo e($profile->defaultProfile()); ?>" alt="<?php echo e($profile->name); ?>" height="30" width="30">
                                                <?php else: ?>
                                                    <img class="media-object img-circle" src="<?php echo e($profile->profilePath().$profile->profile()); ?>" alt="<?php echo e($profile->name); ?>" height="30" width="30">
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <form action="" class="comment-form">
                                                <div class="form-group">
                                                        <textarea name="comment-body" class="comment-body<?php echo e($post->id); ?> form-control ta5" cols="65" rows="1" placeholder="Anong say mo?"></textarea>
                                                </div>
                                                <div class="form-group">
                                                        <button type="submit" id="btn-comment" class="btn btn-primary btn-sm" onclick="comment(<?php echo e($post->id); ?>)">Comment</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <div  class="pull-right mr-1">
                                <a href="<?php echo e(url('/post/'.$post->id)); ?>">View Post <i class="far fa-eye"></i></a>
                            </div>
                        </div>
                        
                        
                    </div>
                    
                </div>
                 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
           
            
        </div>
    
       <div class="col-md-3 hide-mobile sticky hide-tablet">
                <div class="panel panel-default">
                    <div class="panel-heading elegant bold">Mga Chismosa <a class="refresh pull-right">Refresh</a></div>
                        <div class="people-nearby">
                            <?php echo $__env->make('includes.refreshpeople', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading elegant bold">Getting bored? Checkout this awesome games!</div>
                        <div class="panel-body">
                            <p class="cool-orange bold"><i class="fas fa-gamepad"></i> Featured Games</p>
                            <a href="" class="w-100" title="The Sweet Escape Mystery Game">
                                <img src="<?php echo e(asset('img/sweetescape.svg')); ?>" alt="The Sweet Escape" class="img-rounded w-100 shadow-hover">
                            </a>
                        </div>
                </div>

        </div> 
    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>