<div class="panel">
    <div class="panel-heading text-center">
            <a href="<?php echo e(url('/profile')); ?>">
               <?php if($profile->profile() == null): ?>
                <img src="<?php echo e(url($profile->defaultProfile())); ?>" class="img-circle" alt="<?php echo e($profile->name); ?>" width="200" height="200">
               <?php else: ?>
                <img src="<?php echo e(url($profile->profilePath().$profile->profile())); ?>" class="img-circle" alt="<?php echo e($profile->name); ?>" height="200" width="200">
               <?php endif; ?>
            </a>
            <a href="" class="elegant bold size-1"><?php echo e($profile->name); ?></a>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <a href="" class="elegant bold orange-hover">Chinismis</a>
            <p class="cool-orange bold"><?php echo e(count($postDetails)); ?></p>
            </div>
            <div class="col-md-4 col-sm-4">
                <a href="" class="elegant bold orange-hover">Following</a>
                <p class="cool-orange bold">5</p>
            </div>
            <div class="col-md-4 col-sm-4">
                <a href="" class="elegant bold orange-hover">Followers</a>
                <p class="cool-orange bold">3.4mil</p>
            </div>
        </div>
        <div class="row mt-1">
            <ul class="list-unstyled ml-3">
                <li class="mb-3">
                    <i class="far fa-newspaper newspaper"></i><a href="<?php echo e(url('/home')); ?>" class="elegant bold side-nav ml-5">My Newsfeeds</a>
                </li>
                <li class="mb-3">
                    <i class="fas fa-users people"></i><a href="<?php echo e(url('/people')); ?>" class="elegant bold side-nav ml-5">People nearby</a>
                </li>
                <li class="mb-3">
                    <i class="fas fa-camera-retro photo"></i><a href="<?php echo e(url('/gallery')); ?>" class="elegant bold side-nav ml-5"> Photos</a>
                </li>
                <li>
                    <i class="far fa-eye-slash privacy"></i><a href="" class="elegant bold side-nav ml-5"> Privacy, Terms &amp; Agreement</a>
                </li>
            </ul>
        </div>
        <span id="google_translate_element" class="text-center"></span>
    </div>
    