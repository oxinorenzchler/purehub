<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Website Maintenance</title>
    <style>
        body{
            margin 0 auto;
        }
        #maintenance-page{
        background-image:url('/img/maintenance.jpg');
        background-size:contain;
        background-repeat: no-repeat;
        height: 100vh;
        }
        
    </style>
</head>
<body>
    <div id="maintenance-page">
    
    </div>
</body>
</html>

