<div class="text-center" id="footer">
        <div class="container">
                        <div class="row">
                                        <div class="col-lg-6 mt-1">
                                                <p class="elegant bold">Copyright &copy; Pure Hub | <a href="" class="elegant bold">Renzchler Oxiño</a></p>
                                                <p>Capstone 3 - Tuitt Coding Bootcamp</p>
                                        </div>
                                        <div class="col-lg-6">
                                                <h5>Visit our awesome partners!</h5>
                                                <ul class="list-unstyled">
                                                        <li>
                                                                <a href="http://csp3.eugenerationx.com" target="_blank" class="bold">Pure Room</a>
                                                        </li>
                                                        <li>
                                                                <a href="" target="_blank" class="bold">Tuitt Day8</a>
                                                        </li>     
                                                </ul>
                                                <span id="google_translate_element"></span> 
                                        </div>
                                </div>
        </div>
</div>